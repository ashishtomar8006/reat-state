export type NavLinks = {
  label: string
  href: string
}
