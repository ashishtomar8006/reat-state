export type footerlinks = {
    label: string
    href: string
  }
  